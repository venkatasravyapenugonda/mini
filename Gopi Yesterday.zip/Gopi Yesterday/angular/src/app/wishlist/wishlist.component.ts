import { Component, OnInit } from '@angular/core';
import { UserService } from '../user.service';
import { ProductserviceService } from '../productservice.service';

@Component({
  selector: 'app-wishlist',
  templateUrl: './wishlist.component.html',
  styleUrls: ['./wishlist.component.css']
})
export class WishlistComponent implements OnInit {

  products:any[]=[];
  constructor(private userService:UserService,private productService:ProductserviceService) { }

  ngOnInit() {
    this.userService.getWishList().subscribe((data:any)=>{this.products=data;
      console.log(this.products);
    });
    }

    addToCart(prod){
      console.log(prod.proId);
      return this.productService.addToCart(prod.proId);
    }

  }


