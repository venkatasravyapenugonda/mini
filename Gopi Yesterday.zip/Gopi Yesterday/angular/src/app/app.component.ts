import { Component } from '@angular/core';
import { UserService } from './user.service';
import { Router } from '../../node_modules/@angular/router';
import { ProductserviceService } from './productservice.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  products: any[]=[];
  products1: any[]=[];
  constructor(private productService:ProductserviceService,private router:Router) { }
  name:String;
  searchName=true;
  searchId=false;
  searchterm:any;
  
  private _searchterm:string;
  searchterm1:any;


  ngOnInit() {
  }
  
 
    //this.router.navigate(['/search']);
    search(searchterm){
      console.log("in string");
      this.router.navigate(["./search",searchterm])
      
      this.productService.searchByName(searchterm).subscribe((data:any)=>this.products=data);
          
    
       
      }
    
    
  
}
