import { Component, OnInit } from '@angular/core';
import { ProductserviceService } from '../productservice.service';

@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css']
})
export class CartComponent implements OnInit {
  products:any[]=[];
  price:number;
   /* totalprice:String;
  availability:String;
  proCategory:String;
  proPrice:String;
  proDesc:String;
  imageUrl:any; */
  


  constructor(private productService:ProductserviceService) { }

  ngOnInit() {
     this.productService.getCartProducts().subscribe((data:any)=>{this.products=data;
      console.log(this.products);
     
    
    });
    this.productService.getPrice().subscribe((data:any)=>this.price=data);

  }
  
}

