import { Component, OnInit } from '@angular/core';
import { UserService } from '../user.service';
import { Router } from '../../../node_modules/@angular/router';
import { ProductserviceService } from '../productservice.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  model:any={};
  res:number;
  result:string;
  constructor(private userService:UserService,private router:Router,private productService:ProductserviceService) { }


  ngOnInit() {
  }
  onLogin(){
    console.log(this.model.id);
    this.userService.id=this.model.id;
    this.productService.currentUser=this.model.id;
    console.log("Current User in .ts"+this.productService.currentUser)
    
    return this.userService.validateLogin(this.model.id,this.model.password).subscribe((data:number)=>{
      this.res=data;
      console.log(this.res);
      if(this.res==1){
        this.router.navigate(["/productsAdmin"])
      }
      else if(this.res==2){
        this.router.navigate(["/products"])
      }
      else{
        alert("Enter Valid Credentials")
      }

    })
  }

}
