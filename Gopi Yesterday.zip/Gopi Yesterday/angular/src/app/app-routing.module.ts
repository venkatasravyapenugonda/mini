import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { RegistrationComponent } from './registration/registration.component';
import { ProductsComponent } from './products/products.component';
import { CartComponent } from './cart/cart.component';
import { WishlistComponent } from './wishlist/wishlist.component';
import { LogoutComponent } from './logout/logout.component';
import { ProductListComponent } from './product/product-list.component';
import { SearchComponent } from './search/search.component';
import { SearchBymobilesComponent } from './searchByMobiles/search-bymobiles.component';
import { SearchbyheadphonesComponent } from './searchbyheadphones/searchbyheadphones.component';
import { SearchbylapComponent } from './searchbylaptops/searchbylap.component';

const routes: Routes = [
  {path:'login',component:LoginComponent},
  {path:'signup',component:RegistrationComponent},
  {path:'productsAdmin',component:ProductsComponent},
  {path:'products',component:ProductListComponent},
  {path:'cart',component:CartComponent},
  {path:'wishlist',component:WishlistComponent},
  {path:'logout', component:LogoutComponent},
  {path:'search/:id', component:SearchComponent},
  {path:'searchByMobiles', component:SearchBymobilesComponent},
  {path:'searchByHeadPhones', component:SearchbyheadphonesComponent},
  {path:'searchByLaptops', component:SearchbylapComponent}

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
