import { Component, OnInit } from '@angular/core';
import { ProductserviceService } from '../productservice.service';
import { Router, ActivatedRoute } from '../../../node_modules/@angular/router';
import { UserService } from '../user.service';

@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.css']
})
export class SearchComponent implements OnInit {

  products: any[]=[];
  products1: any[]=[];
  constructor(private productService:ProductserviceService,private userService:UserService,private router:Router,private activatedRoute:ActivatedRoute) { }
  name:String;
  searchName=true;
  searchId=false;
  searchterm:any;
  
  private _searchterm:string;
  searchterm1:any;



  ngOnInit() {
    let obj=this.activatedRoute.snapshot.params['id'];
    console.log(obj);
    this.productService.searchByName(obj).subscribe((data:any)=>this.products=data);
  }
  addToCart(prod){
    console.log(".ts angular")
    console.log(prod.proId);
    return this.userService.addToCart(prod.proId)
  
  }
  addToWishlist(prod){
    return this.userService.createWishList(prod.proId);
  }
  

}
