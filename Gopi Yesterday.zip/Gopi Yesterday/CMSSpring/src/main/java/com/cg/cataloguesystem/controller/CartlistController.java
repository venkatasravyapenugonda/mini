package com.cg.cataloguesystem.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cg.cataloguesystem.bean.CartDetails;
import com.cg.cataloguesystem.service.CartlistService;

@RestController
@RequestMapping("/cartlist")
@CrossOrigin(origins="http://localhost:4200")
public class CartlistController {
	@Autowired
	CartlistService cartlistservice;
	
	/*
	 * @PostMapping(value = "/addToCart") public String createCartlist(@RequestParam
	 * String id) { System.out.println("In controller");
	 * cartlistservice.addToCart(id); return "added successfully";
	 * 
	 * 
	 * }
	 */
	@GetMapping("/cart1")
	public Boolean addToCart1(@RequestParam String productId){
		System.out.println("in cart");
			//if(cartlistservice.addToCart(productId,))
				return true;
			//return false;
	}

	@GetMapping("/cart")
	public Boolean addToCart(@RequestParam String productId,String usermail){
		System.out.println("in cart");
			if(cartlistservice.addToCart(productId,usermail))
				return true;
			return false;
	}
   @GetMapping(value = "/getAll")
	public List<CartDetails> getAllDetails(){
		return cartlistservice.getAllCart();
		
	}
   @GetMapping("/getByuserId")
	public CartDetails getByCartId(@RequestParam("id") int id)
	{
	return cartlistservice.getByIdInCartList(id);
	}
   @GetMapping("/price")
	public Double getTotalPrice()
	{
	   	return cartlistservice.price();
	}

}
