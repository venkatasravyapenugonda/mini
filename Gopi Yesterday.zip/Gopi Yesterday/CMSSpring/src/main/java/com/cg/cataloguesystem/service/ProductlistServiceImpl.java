package com.cg.cataloguesystem.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.cataloguesystem.bean.ProductDetails;
import com.cg.cataloguesystem.dao.ProductDetailsDao;

@Service
public class ProductlistServiceImpl implements ProductlistService {
	@Autowired
	ProductDetailsDao productdao;

	@Override
	public ProductDetails createProductDetails(ProductDetails productlist) {
		// TODO Auto-generated method stub
		return productdao.createCartDetails(productlist);
	}

	@Override
	public List<ProductDetails> getAllProduct() {
		// TODO Auto-generated method stub
		return productdao.getAllProduct();
	}

	@Override
	public ProductDetails getByProductId(int id) {
		// TODO Auto-generated method stub
		return productdao.getByProductId(id);
	}

	@Override
	public ProductDetails getByName(String name) {
		// TODO Auto-generated method stub
		return productdao.getByName(name);
	}

	@Override
	public List<ProductDetails> getByProductCategory(String category) {
		// TODO Auto-generated method stub
		return productdao.getByProductCategory(category);
	}

	@Override
	public List<ProductDetails> getByProductPrice(String price) {
		// TODO Auto-generated method stub
		return productdao.getByProductPrice(price);
	}

	@Override
	public List<ProductDetails> searchByCategoryandPrice(String search) {
		// TODO Auto-generated method stub
		return productdao.searchByCategoryandPrice(search);
	}

	@Override
	public boolean getAvailability(String id) {
		// TODO Auto-generated method stub
		return productdao.getAvailability(id);
	}

}
