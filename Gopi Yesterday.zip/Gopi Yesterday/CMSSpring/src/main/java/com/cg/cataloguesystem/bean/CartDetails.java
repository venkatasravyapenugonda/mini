package com.cg.cataloguesystem.bean;

import java.util.List;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection="cart")
public class CartDetails {
	@Id
	private String cartId;
	
	private double totalPrice;
	private Integer quantity;
	private List<ProductDetails> productdetails1;
	
	public double getTotalPrice() {
		return totalPrice;
	}
	public void setTotalPrice(double totalPrice) {
		this.totalPrice = totalPrice;
	}
	public Integer getQuantity() {
		return quantity;
	}
	public void setQuantity(Integer quantity) {
		this.quantity = quantity;
	}
	public List<ProductDetails> getProductdetails1() {
		return productdetails1;
	}
	public void setProductdetails1(List<ProductDetails> productdetails1) {
		this.productdetails1 = productdetails1;
	}
	
	public String getCartId() {
		return cartId;
	}
	public void setCartId(String cartId) {
		this.cartId = cartId;
	}
	public CartDetails() {
		super();
	}
	public CartDetails(String cartId, double totalPrice, Integer quantity, List<ProductDetails> productdetails1) {
		super();
		this.cartId = cartId;
		this.totalPrice = totalPrice;
		this.quantity = quantity;
		this.productdetails1 = productdetails1;
	}
	@Override
	public String toString() {
		return "CartDetails [cartId=" + cartId + ", totalPrice=" + totalPrice + ", quantity=" + quantity
				+ ", productdetails1=" + productdetails1 + "]";
	}
	
	

}
