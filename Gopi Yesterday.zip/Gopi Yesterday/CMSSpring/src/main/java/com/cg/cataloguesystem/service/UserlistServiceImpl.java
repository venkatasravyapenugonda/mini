package com.cg.cataloguesystem.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.cataloguesystem.bean.UserDetails;
import com.cg.cataloguesystem.dao.UserlistDao;

@Service
public class UserlistServiceImpl implements UserlistService {
	@Autowired
	UserlistDao userlistdao;

	@Override
	public Integer createIncomeTax(UserDetails userlist) {
		// TODO Auto-generated method stub
		return userlistdao.createIncomeTax(userlist);
	}

	@Override
	public List<UserDetails> getAllUser() {
		// TODO Auto-generated method stub
		return userlistdao.getAllUser();
	}

	@Override
	public UserDetails getByUserId(int id) {
		// TODO Auto-generated method stub
		return userlistdao.getByUserId(id);
	}

	@Override
	public List<UserDetails> getByName(String name) {
		// TODO Auto-generated method stub
		return userlistdao.getByName(name);
	}

	@Override
	public Integer validateByMailPswd(String mailId, String pswd) {
		// TODO Auto-generated method stub
		return userlistdao.validateByMailPswd(mailId,pswd);
	}

}
