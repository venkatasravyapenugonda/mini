import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Product } from './search/Interface';

@Injectable({
  providedIn: 'root'
})
export class ProductService {
  product:Product[];

  constructor(private http1:HttpClient) { }
  getDetails(storeid,orderid){
    return this.http1.get("http://localhost:9888/PProject/GetOderDetails?sid="+storeid+"&oid="+orderid);

  }

  update(storeid,orderid,status){
    
    return this.http1.put("http://localhost:9888/PProject/update?sid="+storeid+"&oid="+orderid+"&deliverystatus="+status,"");
  }
  searchbyitemname(ordername){
    return this.http1.get("http://localhost:9888/PProject/GetItems?Item="+ordername);
  }
}
