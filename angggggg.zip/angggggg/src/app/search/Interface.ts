export interface Product{
    itemname:String;
    itemid:number;
    price:number;
    quantity:number;
    deliverystatus:String;
    deliveryvalue:String;
}