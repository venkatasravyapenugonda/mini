import { Component, OnInit } from '@angular/core';
import { ProductService } from '../product.service';
import { Product } from './Interface';

@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.css']
})
export class SearchComponent implements OnInit {
  products:Product[];
  private list:any[];
  deliveryStatus:String;
  private result:any[]=[];
  a=false;
  s=false;
  saved:boolean;
  message:any;
  m=false;
  buttonDisplay=false;
  constructor(private service:ProductService) { }

  ngOnInit() {
  }
  //private result:any[];
  getDetails(storeid,orderid){
  
    this.a=true;

    this.service.getDetails(storeid,orderid).subscribe((data:any)=>{this.result=data;
  });
  }
  onUpdate(){
  this.a=false;
this.buttonDisplay=true;
  }
save(storeid,orderid,status){
  this.m=true;
  this.service.update(storeid,orderid,status).subscribe((data:any)=>{
    this.saved=data;
   });
  if(this.saved==false){
    this.message="not saved";
    alert(this.message);

  }
  if(this.saved==true){
    this.message="saved successfully!!";
    alert(this.message);
  }
  
}
order(ordername){
  this.service.searchbyitemname(ordername).subscribe((data:any)=>{
    this.list=data;
    this.s=true;
  });
  }
}


