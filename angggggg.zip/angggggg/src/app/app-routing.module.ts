import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { SearchByIdComponent } from './search-by-id.component';
import { SearchByNameComponent } from './search-by-name.component';

const routes: Routes = [
  {path:'searchbyid',component:SearchByIdComponent},
  {path:'searchbyname',component:SearchByNameComponent},
  {path:'',redirectTo:'/searchbyid',pathMatch:'full'}

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
