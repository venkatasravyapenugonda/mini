import { Component, OnInit } from '@angular/core';
import { ProductService } from './product.service';
import { Product } from './search/Interface';

@Component({
  selector: 'app-search-by-name',
  templateUrl: './search-by-name.component.html',
  styleUrls: ['./search-by-name.component.css']
})
export class SearchByNameComponent implements OnInit {

  products:Product[];
  private list:any[];
  deliveryStatus:String;
  private result:any[]=[];
  a=false;
  s=false;
  saved:boolean;
  message:any;
  m=false;
  buttonDisplay=false;
  constructor(private service:ProductService) { }

  ngOnInit() {
  }
  order(ordername){
   
    this.service.searchbyitemname(ordername).subscribe((data:any)=>{
      this.list=data;
      this.s=true;
 
      });
    }

}
