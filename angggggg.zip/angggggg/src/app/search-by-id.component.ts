import { Component, OnInit } from '@angular/core';
import { ProductService } from './product.service';
import { Product } from './search/Interface';

@Component({
  selector: 'app-search-by-id',
  templateUrl: './search-by-id.component.html',
  styleUrls: ['./search-by-id.component.css']
})
export class SearchByIdComponent implements OnInit {
  products:Product[];
  private list:any[];
  deliveryStatus:String;
  private result:any[]=[];
  a=false;
  s=false;
  saved:boolean;
  message:any;
  m=false;
  buttonDisplay=false;

  constructor(private service:ProductService) { }

  ngOnInit() {
  }
  getDetails(storeid,orderid){
    this.a=true;

    this.service.getDetails(storeid,orderid).subscribe((data:any)=>{this.result=data;
    });
  }
  onUpdate(){
    this.a=false;
  this.buttonDisplay=true;
    }
  save(storeid,orderid,status){
    this.m=true;
    this.service.update(storeid,orderid,status).subscribe((data:any)=>{
      this.saved=data;
    if(this.saved){
      alert("saved successfully!!");
      this.message="saved successfully!!";
    }
    else{
      alert("Not saved successfully!!");

    }
  });
    
  }

}
